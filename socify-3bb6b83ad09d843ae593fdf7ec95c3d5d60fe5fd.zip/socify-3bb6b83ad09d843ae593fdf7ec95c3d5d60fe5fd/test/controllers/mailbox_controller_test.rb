require 'test_helper'

class MailboxControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
